from flask import Flask, render_template, request, jsonify, send_from_directory
import json
import os
from datetime import datetime, timedelta
import random
from typing import List, Dict, Any
import openai
from dataclasses import dataclass, asdict
import uuid

app = Flask(__name__, static_folder='static', template_folder='templates')

# Configure OpenAI (optional)
openai.api_key = os.environ.get('OPENAI_API_KEY')

@dataclass
class Prompt:
    id: str
    title: str
    description: str
    content: str
    preview: str
    category: str
    tags: List[str]
    source: str
    sourceUrl: str
    sourceMetadata: Dict[str, Any]
    likes: int
    shares: int
    views: int
    bookmarks: int
    growthPercentage: int
    trending: bool
    viral: bool
    featured: bool
    createdAt: str = None

    def __post_init__(self):
        if self.createdAt is None:
            self.createdAt = datetime.now().isoformat()

class PromptStorage:
    def __init__(self):
        self.prompts = []
        self.categories = [
            {"name": "Coding & Development", "slug": "coding", "count": 0},
            {"name": "Business & Marketing", "slug": "business", "count": 0},
            {"name": "Creative & Writing", "slug": "creative", "count": 0},
            {"name": "Education & Learning", "slug": "education", "count": 0},
            {"name": "Data & Analytics", "slug": "data", "count": 0},
        ]
        self.trending_tags = []
        self._initialize_prompts()
        self._update_category_counts()
        self._generate_trending_tags()

    def _initialize_prompts(self):
        initial_prompts = [
            {
                "title": "TikTok Content Creator Assistant",
                "description": "Generate viral TikTok video ideas, scripts, and hashtag strategies based on current trends and your niche. Optimized for maximum engagement and reach.",
                "content": "You are a viral TikTok content strategist with 5M+ followers experience. Create compelling TikTok content strategies including:\n\n1. Trending video concepts\n2. Hook-heavy scripts (first 3 seconds)\n3. Viral hashtag combinations\n4. Engagement optimization tactics\n5. Cross-platform adaptation strategies\n\nConsider:\n- Current trending sounds and effects\n- Algorithm optimization techniques\n- Target demographic preferences\n- Brand safety guidelines\n- Community engagement strategies\n\nNiche: [INSERT NICHE]\nTarget audience: [INSERT DEMOGRAPHICS]\nContent pillars: [INSERT PILLARS]",
                "preview": "You are a viral TikTok content strategist with 5M+ followers experience. Create compelling TikTok content...",
                "category": "creative",
                "tags": ["tiktok", "viral", "social-media", "content-creation"],
                "source": "twitter",
                "sourceUrl": "https://twitter.com/viral_prompts",
                "sourceMetadata": {"author": "@ViralCreator", "followers": 150000, "retweets": 892},
                "likes": 3200,
                "shares": 567,
                "views": 15600,
                "bookmarks": 1200,
                "growthPercentage": 1247,
                "trending": True,
                "viral": True,
                "featured": True,
            },
            {
                "title": "Instagram Growth Hacker Pro",
                "description": "Master Instagram growth with AI-powered content strategies, Reels scripts, and engagement tactics that guarantee follower growth and viral reach.",
                "content": "You are an Instagram growth expert who has scaled 50+ accounts to 100K+ followers. Develop a comprehensive Instagram growth strategy including:\n\n1. Content pillars and themes\n2. Viral Reels concepts and scripts\n3. Story engagement sequences\n4. Hashtag research and rotation\n5. Influencer collaboration opportunities\n6. Analytics tracking and optimization\n\nFocus on:\n- Algorithm-friendly posting schedules\n- High-engagement content formats\n- Community building tactics\n- Monetization strategies\n- Cross-promotion opportunities\n\nAccount type: [INSERT TYPE]\nNiche: [INSERT NICHE]\nCurrent followers: [INSERT COUNT]\nGoals: [INSERT GOALS]",
                "preview": "You are an Instagram growth expert who has scaled 50+ accounts to 100K+ followers. Develop a comprehensive...",
                "category": "business",
                "tags": ["instagram", "growth", "social-media", "reels"],
                "source": "reddit",
                "sourceUrl": "https://reddit.com/r/Instagram",
                "sourceMetadata": {"author": "u/instagramguru", "subreddit": "r/Instagram", "upvotes": 2100},
                "likes": 2800,
                "shares": 420,
                "views": 11200,
                "bookmarks": 950,
                "growthPercentage": 890,
                "trending": True,
                "viral": True,
                "featured": False,
            },
            {
                "title": "YouTube Algorithm Optimizer",
                "description": "Create YouTube content that dominates the algorithm with optimized titles, thumbnails, descriptions, and engagement strategies for maximum views and subscribers.",
                "content": "You are a YouTube algorithm specialist who has generated 1B+ views across channels. Optimize YouTube content for maximum reach:\n\n1. Click-worthy titles (70+ CTR)\n2. Thumbnail psychology and design\n3. SEO-optimized descriptions\n4. Engagement-driving hooks\n5. Retention optimization strategies\n6. Community tab content\n\nAlgorithm factors to optimize:\n- Watch time and retention curves\n- Click-through rates\n- Engagement signals (likes, comments, shares)\n- Session duration\n- Subscriber conversion rates\n\nVideo topic: [INSERT TOPIC]\nTarget audience: [INSERT AUDIENCE]\nChannel niche: [INSERT NICHE]\nGoal: [INSERT GOAL]",
                "preview": "You are a YouTube algorithm specialist who has generated 1B+ views across channels. Optimize YouTube content...",
                "category": "business",
                "tags": ["youtube", "algorithm", "seo", "video-marketing"],
                "source": "github",
                "sourceUrl": "https://github.com/youtube-prompts",
                "sourceMetadata": {"repo": "youtube-growth", "stars": 8500, "author": "videogurus"},
                "likes": 1900,
                "shares": 340,
                "views": 8700,
                "bookmarks": 720,
                "growthPercentage": 456,
                "trending": True,
                "viral": False,
                "featured": False,
            },
            {
                "title": "Ultimate Code Review Assistant",
                "description": "Perform comprehensive code reviews with security analysis, performance optimization, and best practice recommendations. Perfect for teams and solo developers.",
                "content": "You are a senior software engineer with 15+ years of experience in code reviews across multiple languages. Perform comprehensive code analysis including:\n\n1. Security vulnerability assessment\n2. Performance optimization opportunities\n3. Code maintainability and readability\n4. Best practice adherence\n5. Testing coverage recommendations\n6. Architecture improvement suggestions\n\nFor each review, provide:\n- Critical issues (security, bugs)\n- Performance improvements\n- Code quality enhancements\n- Documentation suggestions\n- Testing recommendations\n\nCode language: [INSERT LANGUAGE]\nFramework: [INSERT FRAMEWORK]\nCode complexity: [INSERT COMPLEXITY]",
                "preview": "You are a senior software engineer with 15+ years of experience in code reviews across multiple languages...",
                "category": "coding",
                "tags": ["code-review", "security", "performance", "best-practices"],
                "source": "github",
                "sourceUrl": "https://github.com/code-review-prompts",
                "sourceMetadata": {"repo": "code-quality", "stars": 12500, "author": "codereviewer"},
                "likes": 4200,
                "shares": 890,
                "views": 18900,
                "bookmarks": 1800,
                "growthPercentage": 67,
                "trending": True,
                "viral": False,
                "featured": True,
            },
            {
                "title": "Advanced Data Scientist",
                "description": "Analyze complex datasets, build predictive models, and extract actionable insights with advanced statistical methods and machine learning techniques.",
                "content": "You are a data scientist with PhD-level expertise in statistics and machine learning. Perform advanced data analysis including:\n\n1. Exploratory data analysis (EDA)\n2. Statistical hypothesis testing\n3. Predictive model development\n4. Feature engineering and selection\n5. Model validation and interpretation\n6. Business insight generation\n\nAnalysis approach:\n- Data quality assessment\n- Distribution analysis\n- Correlation and causation investigation\n- Model comparison and selection\n- Performance metrics evaluation\n- Actionable recommendations\n\nDataset: [INSERT DATASET DESCRIPTION]\nBusiness objective: [INSERT OBJECTIVE]\nConstraints: [INSERT CONSTRAINTS]",
                "preview": "You are a data scientist with PhD-level expertise in statistics and machine learning. Perform advanced data analysis...",
                "category": "data",
                "tags": ["data-science", "machine-learning", "statistics", "analytics"],
                "source": "reddit",
                "sourceUrl": "https://reddit.com/r/MachineLearning",
                "sourceMetadata": {"author": "u/datascientist", "subreddit": "r/MachineLearning", "upvotes": 3400},
                "likes": 2900,
                "shares": 520,
                "views": 12800,
                "bookmarks": 1100,
                "growthPercentage": 89,
                "trending": True,
                "viral": False,
                "featured": False,
            },
            {
                "title": "LinkedIn Viral Post Generator",
                "description": "Create LinkedIn posts that generate massive engagement, comments, and shares. Perfect for thought leadership, business growth, and professional networking.",
                "content": "You are a LinkedIn thought leader with 500K+ followers and posts that regularly get 10K+ reactions. Create viral LinkedIn content including:\n\n1. Attention-grabbing hooks\n2. Story-driven narratives\n3. Professional insights\n4. Call-to-action strategies\n5. Comment-driving questions\n6. Connection building tactics\n\nPost types to master:\n- Personal success stories\n- Industry insights\n- Controversial takes (professional)\n- Behind-the-scenes content\n- Educational carousels\n- Poll discussions\n\nTopic: [INSERT TOPIC]\nIndustry: [INSERT INDUSTRY]\nGoal: [INSERT GOAL]\nTarget audience: [INSERT AUDIENCE]",
                "preview": "You are a LinkedIn thought leader with 500K+ followers and posts that regularly get 10K+ reactions...",
                "category": "business",
                "tags": ["linkedin", "networking", "thought-leadership", "b2b"],
                "source": "discord",
                "sourceUrl": "https://discord.gg/marketing-pros",
                "sourceMetadata": {"server": "Marketing Pros", "members": 45000, "author": "LinkedInGuru#7890"},
                "likes": 1650,
                "shares": 280,
                "views": 6800,
                "bookmarks": 590,
                "growthPercentage": 234,
                "trending": True,
                "viral": False,
                "featured": False,
            },
            {
                "title": "Personalized Tutor Assistant",
                "description": "Create adaptive learning experiences with personalized explanations, practice problems, and study plans tailored to individual learning styles and pace.",
                "content": "You are an expert educator with 20+ years of teaching experience across all subjects. Create personalized learning experiences including:\n\n1. Learning style assessment\n2. Adaptive explanation methods\n3. Progressive difficulty scaling\n4. Interactive practice problems\n5. Knowledge gap identification\n6. Motivation and encouragement\n\nTeaching strategies:\n- Visual, auditory, and kinesthetic approaches\n- Socratic questioning methods\n- Real-world application examples\n- Memory techniques and mnemonics\n- Progress tracking and celebration\n- Mistake analysis and correction\n\nSubject: [INSERT SUBJECT]\nStudent level: [INSERT LEVEL]\nLearning goals: [INSERT GOALS]\nTime available: [INSERT TIME]",
                "preview": "You are an expert educator with 20+ years of teaching experience across all subjects. Create personalized learning...",
                "category": "education",
                "tags": ["education", "tutoring", "personalized-learning", "study-help"],
                "source": "reddit",
                "sourceUrl": "https://reddit.com/r/Education",
                "sourceMetadata": {"author": "u/educator", "subreddit": "r/Education", "upvotes": 1800},
                "likes": 1200,
                "shares": 210,
                "views": 5600,
                "bookmarks": 480,
                "growthPercentage": 45,
                "trending": False,
                "viral": False,
                "featured": False,
            },
        ]

        for prompt_data in initial_prompts:
            prompt = Prompt(
                id=str(uuid.uuid4()),
                **prompt_data
            )
            self.prompts.append(prompt)

    def _update_category_counts(self):
        for category in self.categories:
            category["count"] = len([p for p in self.prompts if p.category == category["slug"]])

    def _generate_trending_tags(self):
        all_tags = []
        for prompt in self.prompts:
            all_tags.extend(prompt.tags)
        
        tag_counts = {}
        for tag in all_tags:
            tag_counts[tag] = tag_counts.get(tag, 0) + 1
        
        self.trending_tags = [
            {"tag": tag, "growthPercentage": random.randint(50, 500), "count": count}
            for tag, count in sorted(tag_counts.items(), key=lambda x: x[1], reverse=True)[:10]
        ]

    def get_prompts(self, filters=None):
        filtered_prompts = self.prompts.copy()
        
        if filters:
            if filters.get('category'):
                filtered_prompts = [p for p in filtered_prompts if p.category == filters['category']]
            
            if filters.get('tags'):
                tag_list = filters['tags'].split(',') if isinstance(filters['tags'], str) else filters['tags']
                filtered_prompts = [p for p in filtered_prompts if any(tag in p.tags for tag in tag_list)]
            
            if filters.get('search'):
                search_term = filters['search'].lower()
                filtered_prompts = [
                    p for p in filtered_prompts 
                    if search_term in p.title.lower() or search_term in p.description.lower()
                ]
        
        # Sort prompts
        sort_by = filters.get('sortBy', 'trending') if filters else 'trending'
        if sort_by == 'trending':
            filtered_prompts.sort(key=lambda x: (x.trending, x.growthPercentage), reverse=True)
        elif sort_by == 'popular':
            filtered_prompts.sort(key=lambda x: x.likes, reverse=True)
        elif sort_by == 'recent':
            filtered_prompts.sort(key=lambda x: x.createdAt, reverse=True)
        
        return [asdict(p) for p in filtered_prompts]

    def add_prompt(self, prompt_data):
        prompt = Prompt(
            id=str(uuid.uuid4()),
            **prompt_data
        )
        self.prompts.append(prompt)
        self._update_category_counts()
        return asdict(prompt)

    def get_stats(self):
        total = len(self.prompts)
        trending = len([p for p in self.prompts if p.trending])
        return {
            "totalPrompts": total,
            "newToday": total,  # Simplified for demo
            "trendingNow": trending
        }

# Initialize storage
storage = PromptStorage()

@app.route('/')
def home():
    return render_template('index.html')

@app.route('/api/prompts')
def get_prompts():
    filters = {
        'category': request.args.get('category'),
        'tags': request.args.get('tags'),
        'search': request.args.get('search'),
        'sortBy': request.args.get('sortBy', 'trending')
    }
    prompts = storage.get_prompts(filters)
    return jsonify(prompts)

@app.route('/api/categories')
def get_categories():
    return jsonify(storage.categories)

@app.route('/api/trending-tags')
def get_trending_tags():
    return jsonify(storage.trending_tags)

@app.route('/api/stats')
def get_stats():
    return jsonify(storage.get_stats())

@app.route('/api/check-updates')
def check_updates():
    # Simulate periodic updates
    return jsonify({
        "hasUpdates": random.choice([True, False]),
        "newPromptsCount": random.randint(0, 10),
        "lastUpdate": datetime.now().isoformat()
    })

@app.route('/api/generate-prompt', methods=['POST'])
def generate_prompt():
    data = request.get_json()
    
    if not data or not data.get('idea'):
        return jsonify({"error": "Idea is required"}), 400
    
    idea = data['idea']
    category = data.get('category', 'creative')
    tone = data.get('tone', 'professional')
    length = data.get('length', 'medium')
    
    # Try to use OpenAI if available, otherwise use fallback
    try:
        if openai.api_key:
            response = openai.chat.completions.create(
                model="gpt-4o",
                messages=[
                    {
                        "role": "system",
                        "content": f"You are an expert AI prompt engineer. Create a detailed, working AI prompt based on the user's idea. The prompt should be {tone} in tone and {length} in length. Format your response as JSON with 'title', 'description', and 'content' fields."
                    },
                    {
                        "role": "user",
                        "content": f"Create an AI prompt for: {idea}"
                    }
                ],
                response_format={"type": "json_object"}
            )
            
            generated = json.loads(response.choices[0].message.content)
        else:
            # Fallback generation without API key
            generated = {
                "title": f"Custom {category.title()} Assistant",
                "description": f"A specialized AI assistant for {idea}. Optimized for {tone} communication and {length} responses.",
                "content": f"You are an expert {category} assistant specialized in {idea}. Provide {tone} guidance with {length} explanations.\n\nKey areas to focus on:\n1. Understanding the specific requirements\n2. Providing actionable solutions\n3. Explaining the reasoning behind recommendations\n4. Adapting to user expertise level\n5. Offering practical next steps\n\nContext: [INSERT CONTEXT]\nSpecific requirements: [INSERT REQUIREMENTS]\nDesired outcome: [INSERT OUTCOME]"
            }
    
    except Exception as e:
        # Fallback if OpenAI fails
        generated = {
            "title": f"Custom {category.title()} Assistant",
            "description": f"A specialized AI assistant for {idea}. Optimized for {tone} communication and {length} responses.",
            "content": f"You are an expert {category} assistant specialized in {idea}. Provide {tone} guidance with {length} explanations.\n\nKey areas to focus on:\n1. Understanding the specific requirements\n2. Providing actionable solutions\n3. Explaining the reasoning behind recommendations\n4. Adapting to user expertise level\n5. Offering practical next steps\n\nContext: [INSERT CONTEXT]\nSpecific requirements: [INSERT REQUIREMENTS]\nDesired outcome: [INSERT OUTCOME]"
        }
    
    # Create new prompt
    new_prompt = {
        "title": generated["title"],
        "description": generated["description"],
        "content": generated["content"],
        "preview": generated["content"][:100] + "...",
        "category": category,
        "tags": ["custom", category, "ai-generated"],
        "source": "user-generated",
        "sourceUrl": "",
        "sourceMetadata": {"type": "custom", "generated": True},
        "likes": 0,
        "shares": 0,
        "views": 1,
        "bookmarks": 0,
        "growthPercentage": 0,
        "trending": False,
        "viral": False,
        "featured": False,
    }
    
    created_prompt = storage.add_prompt(new_prompt)
    return jsonify(created_prompt)

if __name__ == '__main__':
    port = int(os.environ.get('PORT', 5000))
    app.run(host='0.0.0.0', port=port, debug=False)