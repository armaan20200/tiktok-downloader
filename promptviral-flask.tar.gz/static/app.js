// Global state
let prompts = [];
let filteredPrompts = [];
let displayedPrompts = [];
let currentPage = 1;
let currentFilters = {
    category: '',
    search: '',
    sortBy: 'trending'
};

// Initialize app
document.addEventListener('DOMContentLoaded', function() {
    initializeTheme();
    setupEventListeners();
    loadInitialData();
    startUpdateTimer();
});

// Theme management
function initializeTheme() {
    const theme = localStorage.getItem('theme') || 'light';
    document.documentElement.classList.toggle('dark', theme === 'dark');
}

function toggleTheme() {
    const isDark = document.documentElement.classList.contains('dark');
    const newTheme = isDark ? 'light' : 'dark';
    
    document.documentElement.classList.toggle('dark', newTheme === 'dark');
    localStorage.setItem('theme', newTheme);
}

// Event listeners
function setupEventListeners() {
    // Theme toggle
    document.getElementById('themeToggle').addEventListener('click', toggleTheme);
    
    // Search
    document.getElementById('searchInput').addEventListener('input', debounce(handleSearch, 300));
    
    // Sort
    document.getElementById('sortSelect').addEventListener('change', handleSort);
    
    // Load more
    document.getElementById('loadMoreBtn').addEventListener('click', loadMore);
    
    // Create prompt modal
    document.getElementById('createPromptBtn').addEventListener('click', showCreateModal);
    document.getElementById('closeModalBtn').addEventListener('click', hideCreateModal);
    document.getElementById('createPromptForm').addEventListener('submit', handleCreatePrompt);
    
    // Prompt detail modal
    document.getElementById('closeDetailModalBtn').addEventListener('click', hideDetailModal);
    
    // Click outside modal to close
    document.getElementById('createPromptModal').addEventListener('click', function(e) {
        if (e.target === this) hideCreateModal();
    });
    
    document.getElementById('promptDetailModal').addEventListener('click', function(e) {
        if (e.target === this) hideDetailModal();
    });
}

// Data loading
async function loadInitialData() {
    try {
        const [promptsRes, categoriesRes, tagsRes, statsRes] = await Promise.all([
            fetch('/api/prompts'),
            fetch('/api/categories'),
            fetch('/api/trending-tags'),
            fetch('/api/stats')
        ]);
        
        prompts = await promptsRes.json();
        const categories = await categoriesRes.json();
        const trendingTags = await tagsRes.json();
        const stats = await statsRes.json();
        
        renderCategories(categories);
        renderTrendingTags(trendingTags);
        renderStats(stats);
        
        applyFilters();
        
    } catch (error) {
        console.error('Error loading data:', error);
        showError('Failed to load data. Please refresh the page.');
    }
}

async function refreshData() {
    try {
        const response = await fetch('/api/prompts?' + new URLSearchParams(currentFilters));
        prompts = await response.json();
        applyFilters();
    } catch (error) {
        console.error('Error refreshing data:', error);
    }
}

// Filtering and sorting
function applyFilters() {
    filteredPrompts = prompts.filter(prompt => {
        // Category filter
        if (currentFilters.category && prompt.category !== currentFilters.category) {
            return false;
        }
        
        // Search filter
        if (currentFilters.search) {
            const searchTerm = currentFilters.search.toLowerCase();
            if (!prompt.title.toLowerCase().includes(searchTerm) && 
                !prompt.description.toLowerCase().includes(searchTerm)) {
                return false;
            }
        }
        
        return true;
    });
    
    // Sort prompts
    sortPrompts();
    
    // Reset pagination
    currentPage = 1;
    updateDisplayedPrompts();
}

function sortPrompts() {
    switch (currentFilters.sortBy) {
        case 'trending':
            filteredPrompts.sort((a, b) => {
                if (a.trending && !b.trending) return -1;
                if (!a.trending && b.trending) return 1;
                return b.growthPercentage - a.growthPercentage;
            });
            break;
        case 'popular':
            filteredPrompts.sort((a, b) => b.likes - a.likes);
            break;
        case 'recent':
            filteredPrompts.sort((a, b) => new Date(b.createdAt) - new Date(a.createdAt));
            break;
    }
}

function updateDisplayedPrompts() {
    const itemsPerPage = 12;
    const endIndex = currentPage * itemsPerPage;
    displayedPrompts = filteredPrompts.slice(0, endIndex);
    
    renderPrompts();
    updateLoadMoreButton();
}

// Event handlers
function handleSearch(e) {
    currentFilters.search = e.target.value;
    applyFilters();
}

function handleSort(e) {
    currentFilters.sortBy = e.target.value;
    applyFilters();
}

function handleCategoryFilter(category) {
    currentFilters.category = currentFilters.category === category ? '' : category;
    applyFilters();
    
    // Update category button states
    updateCategoryButtons();
}

function loadMore() {
    currentPage++;
    updateDisplayedPrompts();
}

// Rendering functions
function renderPrompts() {
    const grid = document.getElementById('promptsGrid');
    
    if (displayedPrompts.length === 0) {
        grid.innerHTML = `
            <div class="col-span-full text-center py-12">
                <div class="text-gray-400 dark:text-slate-500 mb-4">
                    <i class="lucide-search h-12 w-12 mx-auto mb-4"></i>
                    <h3 class="text-lg font-semibold mb-2">No prompts found</h3>
                    <p>Try adjusting your search or filters</p>
                </div>
            </div>
        `;
        return;
    }
    
    grid.innerHTML = displayedPrompts.map(prompt => createPromptCard(prompt)).join('');
    
    // Add click listeners to prompt cards
    grid.querySelectorAll('[data-prompt-id]').forEach(card => {
        card.addEventListener('click', () => showPromptDetail(card.dataset.promptId));
    });
}

function createPromptCard(prompt) {
    const sourceIcon = getSourceIcon(prompt.source);
    const categoryColor = getCategoryColor(prompt.category);
    
    return `
        <div data-prompt-id="${prompt.id}" class="bg-white dark:bg-slate-800 rounded-xl border border-gray-200 dark:border-slate-700 p-6 hover:shadow-lg transition-shadow cursor-pointer group">
            <!-- Header -->
            <div class="flex items-start justify-between mb-4">
                <div class="flex items-center space-x-2">
                    <div class="w-6 h-6 ${categoryColor} rounded-md flex items-center justify-center">
                        <i class="${sourceIcon} h-3 w-3 text-white"></i>
                    </div>
                    <span class="text-xs font-medium text-gray-600 dark:text-slate-400">${prompt.source}</span>
                </div>
                ${prompt.trending ? '<span class="px-2 py-1 bg-red-100 dark:bg-red-900 text-red-600 dark:text-red-300 text-xs font-medium rounded-full">🔥 Trending</span>' : ''}
                ${prompt.viral ? '<span class="px-2 py-1 bg-green-100 dark:bg-green-900 text-green-600 dark:text-green-300 text-xs font-medium rounded-full">⚡ Viral</span>' : ''}
            </div>
            
            <!-- Title -->
            <h3 class="text-lg font-semibold text-gray-900 dark:text-white mb-2 group-hover:text-primary transition-colors">
                ${prompt.title}
            </h3>
            
            <!-- Description -->
            <p class="text-sm text-gray-600 dark:text-slate-400 mb-4 line-clamp-3">
                ${prompt.description}
            </p>
            
            <!-- Preview -->
            <div class="bg-gray-50 dark:bg-slate-700 rounded-lg p-3 mb-4">
                <p class="text-xs text-gray-700 dark:text-slate-300 font-mono leading-relaxed">
                    ${prompt.preview}
                </p>
            </div>
            
            <!-- Tags -->
            <div class="flex flex-wrap gap-1 mb-4">
                ${prompt.tags.slice(0, 3).map(tag => 
                    `<span class="px-2 py-1 bg-primary/10 text-primary text-xs font-medium rounded-md">#${tag}</span>`
                ).join('')}
                ${prompt.tags.length > 3 ? `<span class="text-xs text-gray-400 dark:text-slate-500">+${prompt.tags.length - 3} more</span>` : ''}
            </div>
            
            <!-- Metrics -->
            <div class="flex items-center justify-between text-xs text-gray-500 dark:text-slate-400">
                <div class="flex items-center space-x-4">
                    <span class="flex items-center space-x-1">
                        <i class="lucide-heart h-3 w-3"></i>
                        <span>${formatNumber(prompt.likes)}</span>
                    </span>
                    <span class="flex items-center space-x-1">
                        <i class="lucide-eye h-3 w-3"></i>
                        <span>${formatNumber(prompt.views)}</span>
                    </span>
                    <span class="flex items-center space-x-1">
                        <i class="lucide-share h-3 w-3"></i>
                        <span>${formatNumber(prompt.shares)}</span>
                    </span>
                </div>
                ${prompt.growthPercentage > 0 ? 
                    `<span class="text-green-600 dark:text-green-400 font-medium">↗ ${prompt.growthPercentage}%</span>` : ''
                }
            </div>
        </div>
    `;
}

function renderCategories(categories) {
    const container = document.getElementById('categoriesList');
    container.innerHTML = categories.map(category => `
        <button 
            onclick="handleCategoryFilter('${category.slug}')" 
            class="w-full text-left px-3 py-2 text-sm rounded-lg hover:bg-gray-100 dark:hover:bg-slate-700 transition-colors category-btn"
            data-category="${category.slug}"
        >
            <div class="flex justify-between items-center">
                <span class="text-gray-700 dark:text-slate-300">${category.name}</span>
                <span class="text-xs text-gray-500 dark:text-slate-400">${category.count}</span>
            </div>
        </button>
    `).join('');
}

function renderTrendingTags(tags) {
    const container = document.getElementById('trendingTags');
    container.innerHTML = tags.slice(0, 8).map(tag => `
        <button 
            onclick="handleTagFilter('${tag.tag}')"
            class="px-2 py-1 bg-gray-100 dark:bg-slate-700 text-gray-700 dark:text-slate-300 text-xs rounded-md hover:bg-primary hover:text-white transition-colors"
        >
            #${tag.tag}
            <span class="text-green-500 ml-1">+${tag.growthPercentage}%</span>
        </button>
    `).join('');
}

function renderStats(stats) {
    document.getElementById('totalPrompts').textContent = stats.totalPrompts;
    document.getElementById('newToday').textContent = stats.newToday;
    document.getElementById('trendingNow').textContent = stats.trendingNow;
}

function updateLoadMoreButton() {
    const button = document.getElementById('loadMoreBtn');
    const container = document.getElementById('loadMoreContainer');
    
    if (displayedPrompts.length >= filteredPrompts.length) {
        container.style.display = 'none';
    } else {
        container.style.display = 'block';
    }
}

function updateCategoryButtons() {
    document.querySelectorAll('.category-btn').forEach(btn => {
        btn.classList.toggle('bg-primary', btn.dataset.category === currentFilters.category);
        btn.classList.toggle('text-white', btn.dataset.category === currentFilters.category);
    });
}

// Modal functions
function showCreateModal() {
    document.getElementById('createPromptModal').classList.remove('hidden');
    document.getElementById('createPromptModal').classList.add('flex');
}

function hideCreateModal() {
    document.getElementById('createPromptModal').classList.add('hidden');
    document.getElementById('createPromptModal').classList.remove('flex');
}

function showPromptDetail(promptId) {
    const prompt = prompts.find(p => p.id === promptId);
    if (!prompt) return;
    
    document.getElementById('promptDetailTitle').textContent = prompt.title;
    document.getElementById('promptDetailContent').innerHTML = `
        <div class="space-y-6">
            <div>
                <h3 class="text-lg font-semibold text-gray-900 dark:text-white mb-2">Description</h3>
                <p class="text-gray-700 dark:text-slate-300">${prompt.description}</p>
            </div>
            
            <div>
                <h3 class="text-lg font-semibold text-gray-900 dark:text-white mb-2">Full Prompt</h3>
                <div class="bg-gray-50 dark:bg-slate-700 rounded-lg p-4">
                    <pre class="text-sm text-gray-700 dark:text-slate-300 whitespace-pre-wrap font-mono">${prompt.content}</pre>
                </div>
                <button onclick="copyToClipboard('${prompt.content.replace(/'/g, "\\'")}', this)" class="mt-2 px-3 py-1 bg-primary text-white text-sm rounded-md hover:bg-primary/90 transition-colors">
                    Copy Prompt
                </button>
            </div>
            
            <div class="grid grid-cols-2 md:grid-cols-4 gap-4 p-4 bg-gray-50 dark:bg-slate-700 rounded-lg">
                <div class="text-center">
                    <div class="text-lg font-semibold text-gray-900 dark:text-white">${formatNumber(prompt.likes)}</div>
                    <div class="text-xs text-gray-500 dark:text-slate-400">Likes</div>
                </div>
                <div class="text-center">
                    <div class="text-lg font-semibold text-gray-900 dark:text-white">${formatNumber(prompt.views)}</div>
                    <div class="text-xs text-gray-500 dark:text-slate-400">Views</div>
                </div>
                <div class="text-center">
                    <div class="text-lg font-semibold text-gray-900 dark:text-white">${formatNumber(prompt.shares)}</div>
                    <div class="text-xs text-gray-500 dark:text-slate-400">Shares</div>
                </div>
                <div class="text-center">
                    <div class="text-lg font-semibold text-green-600 dark:text-green-400">${prompt.growthPercentage}%</div>
                    <div class="text-xs text-gray-500 dark:text-slate-400">Growth</div>
                </div>
            </div>
        </div>
    `;
    
    document.getElementById('promptDetailModal').classList.remove('hidden');
    document.getElementById('promptDetailModal').classList.add('flex');
}

function hideDetailModal() {
    document.getElementById('promptDetailModal').classList.add('hidden');
    document.getElementById('promptDetailModal').classList.remove('flex');
}

// Create prompt functionality
async function handleCreatePrompt(e) {
    e.preventDefault();
    
    const button = document.getElementById('generateBtn');
    const originalText = button.innerHTML;
    
    button.innerHTML = '<i class="lucide-loader-2 h-5 w-5 animate-spin"></i><span>Generating...</span>';
    button.disabled = true;
    
    try {
        const formData = {
            idea: document.getElementById('promptIdea').value,
            category: document.getElementById('promptCategory').value,
            tone: document.getElementById('promptTone').value,
            length: document.getElementById('promptLength').value
        };
        
        const response = await fetch('/api/generate-prompt', {
            method: 'POST',
            headers: { 'Content-Type': 'application/json' },
            body: JSON.stringify(formData)
        });
        
        if (response.ok) {
            const newPrompt = await response.json();
            prompts.unshift(newPrompt);
            applyFilters();
            
            hideCreateModal();
            document.getElementById('createPromptForm').reset();
            
            showSuccess('Custom prompt generated successfully!');
        } else {
            throw new Error('Failed to generate prompt');
        }
        
    } catch (error) {
        console.error('Error generating prompt:', error);
        showError('Failed to generate prompt. Please try again.');
    } finally {
        button.innerHTML = originalText;
        button.disabled = false;
    }
}

// Utility functions
function debounce(func, wait) {
    let timeout;
    return function executedFunction(...args) {
        const later = () => {
            clearTimeout(timeout);
            func(...args);
        };
        clearTimeout(timeout);
        timeout = setTimeout(later, wait);
    };
}

function formatNumber(num) {
    if (num >= 1000000) return (num / 1000000).toFixed(1) + 'M';
    if (num >= 1000) return (num / 1000).toFixed(1) + 'K';
    return num.toString();
}

function getSourceIcon(source) {
    const icons = {
        reddit: 'lucide-message-circle',
        twitter: 'lucide-twitter',
        github: 'lucide-github',
        discord: 'lucide-message-square',
        'user-generated': 'lucide-user'
    };
    return icons[source] || 'lucide-link';
}

function getCategoryColor(category) {
    const colors = {
        coding: 'bg-blue-500',
        business: 'bg-green-500',
        creative: 'bg-purple-500',
        education: 'bg-yellow-500',
        data: 'bg-red-500'
    };
    return colors[category] || 'bg-gray-500';
}

function copyToClipboard(text, button) {
    navigator.clipboard.writeText(text).then(() => {
        const original = button.textContent;
        button.textContent = 'Copied!';
        button.classList.add('bg-green-500');
        
        setTimeout(() => {
            button.textContent = original;
            button.classList.remove('bg-green-500');
        }, 2000);
    });
}

function showSuccess(message) {
    // Simple toast notification
    const toast = document.createElement('div');
    toast.className = 'fixed top-4 right-4 bg-green-500 text-white px-4 py-2 rounded-lg shadow-lg z-50';
    toast.textContent = message;
    document.body.appendChild(toast);
    
    setTimeout(() => {
        document.body.removeChild(toast);
    }, 3000);
}

function showError(message) {
    // Simple toast notification
    const toast = document.createElement('div');
    toast.className = 'fixed top-4 right-4 bg-red-500 text-white px-4 py-2 rounded-lg shadow-lg z-50';
    toast.textContent = message;
    document.body.appendChild(toast);
    
    setTimeout(() => {
        document.body.removeChild(toast);
    }, 3000);
}

function handleTagFilter(tag) {
    currentFilters.search = tag;
    document.getElementById('searchInput').value = tag;
    applyFilters();
}

// Update timer
function startUpdateTimer() {
    let minutes = 20;
    let seconds = 0;
    
    const updateDisplay = () => {
        const display = `${minutes.toString().padStart(2, '0')}:${seconds.toString().padStart(2, '0')}`;
        document.getElementById('nextUpdate').textContent = `Next update in ${display}`;
    };
    
    const timer = setInterval(() => {
        seconds--;
        if (seconds < 0) {
            minutes--;
            seconds = 59;
        }
        
        if (minutes < 0) {
            minutes = 19;
            seconds = 59;
            // Simulate update check
            refreshData();
        }
        
        updateDisplay();
    }, 1000);
    
    updateDisplay();
}