# PromptViral - Flask Version

A comprehensive viral prompts discovery platform built with Flask, ready for deployment on Render.

## Features

- **Viral Prompt Discovery**: Browse thousands of trending AI prompts from Reddit, Twitter, GitHub, and Discord
- **Custom Prompt Generator**: Turn any idea into a working AI prompt using AI assistance
- **Real-time Updates**: System updates every 20 minutes with new viral content
- **Advanced Filtering**: Search by category, tags, popularity, and trending status
- **Responsive Design**: Works perfectly on desktop and mobile devices
- **Dark/Light Theme**: Toggle between themes with persistent preferences
- **SEO Optimized**: Fully optimized for search engines to capture maximum traffic

## Quick Deploy to Render

1. **Fork/Download this repository**
2. **Connect to Render**:
   - Go to [render.com](https://render.com)
   - Click "New" > "Web Service"
   - Connect your GitHub repository or upload files
3. **Configure Environment**:
   - Set `OPENAI_API_KEY` (optional - works without it)
   - All other settings will be auto-configured via `render.yaml`
4. **Deploy**: Click "Deploy Web Service"

Your site will be live at `https://your-app-name.onrender.com`

## Local Development

1. **Install Python 3.9+**
2. **Install dependencies**:
   ```bash
   pip install -r requirements.txt
   ```
3. **Set environment variables** (optional):
   ```bash
   export OPENAI_API_KEY=your_api_key_here
   ```
4. **Run the application**:
   ```bash
   python app.py
   ```
5. **Visit**: http://localhost:5000

## Environment Variables

- `OPENAI_API_KEY` (optional): For AI-powered custom prompt generation
- `PORT` (auto-set by Render): Port for the web server

## Project Structure

```
flask_version/
├── app.py              # Main Flask application
├── requirements.txt    # Python dependencies
├── render.yaml        # Render deployment config
├── templates/
│   └── index.html     # Main HTML template
├── static/
│   └── app.js         # Frontend JavaScript
└── README.md          # This file
```

## Key Components

### Backend (Flask)
- **Prompt Storage**: In-memory storage with comprehensive seed data
- **API Endpoints**: RESTful APIs for prompts, categories, stats, and generation
- **AI Integration**: Optional OpenAI integration for custom prompt generation
- **Fallback System**: Works fully without external APIs

### Frontend (Vanilla JavaScript)
- **Modern UI**: Clean, responsive design with Tailwind CSS
- **Real-time Features**: Auto-updating content and live search
- **Interactive Elements**: Modal dialogs, filtering, pagination
- **Performance**: Optimized loading and smooth transitions

### SEO & Marketing
- **Meta Tags**: Comprehensive SEO meta tags and Open Graph
- **Structured Data**: JSON-LD markup for search engines
- **Keywords**: Optimized for AI prompt discovery searches
- **Social Sharing**: Ready for social media sharing

## Customization

### Adding More Prompts
Edit the `initial_prompts` array in `app.py` to add more seed data.

### Styling
The site uses Tailwind CSS via CDN. Modify the HTML classes in `templates/index.html` for styling changes.

### API Integration
To add real external API integration, modify the data fetching functions in `app.py`.

## Performance

- **Fast Loading**: Minimal dependencies and optimized assets
- **Responsive**: Works on all device sizes
- **Scalable**: Ready for traffic growth with proper hosting

## Support

For issues or questions:
1. Check the browser console for JavaScript errors
2. Check server logs for Python errors
3. Ensure all dependencies are installed correctly

## License

Open source - feel free to modify and use for your projects.

---

**Ready to deploy!** This Flask version gives you a production-ready viral prompts platform that you can host anywhere.